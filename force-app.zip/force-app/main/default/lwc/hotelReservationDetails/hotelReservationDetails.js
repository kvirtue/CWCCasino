import { LightningElement, api } from 'lwc';

export default class HotelReservationDetails extends LightningElement {
    @api value;

    get hasData() {
        return this.value && this.value.hotels && this.value.hotels.length > 0;
    }

    get hotelCount() {
        return this.value && this.value.hotels ? this.value.hotels.length : 0;
    }

    get searchSummary() {
        return this.value && this.value.searchSummary ? this.value.searchSummary : '';
    }

    get checkInDate() {
        return this.value && this.value.checkInDate ? this.value.checkInDate : '';
    }

    get checkOutDate() {
        return this.value && this.value.checkOutDate ? this.value.checkOutDate : '';
    }

    get city() {
        return this.value && this.value.city ? this.value.city : '';
    }

    get hotels() {
        return this.value && this.value.hotels ? this.value.hotels : [];
    }

    handleHotelSelect(event) {
        const selectedHotel = event.detail.hotel;
        // Dispatch event to notify parent component about selection
        const hotelSelectedEvent = new CustomEvent('hotelselect', {
            detail: { hotel: selectedHotel }
        });
        this.dispatchEvent(hotelSelectedEvent);
    }
}
